#define DEBUG_KEYFRAMES // To Visualize keyframes
#define SAVE_KEYFRAMES // To save image, depth and idepth matrix of the correspoding keyframe 
